'use client';

import VisitorServiceList from '@/components/VisitorServiceList';

const VisitorPage = () => {
  return <VisitorServiceList />;
};

export default VisitorPage;
