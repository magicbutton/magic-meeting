"use client";

import VisitorServiceView from "@/components/VisitorServiceView";

interface VisitorProps {
  params: {
    id: string;
  };
}

const VisitorViewPage = (props: VisitorProps) => {
  const { id } = props.params;

  return <VisitorServiceView id={id} />;
};

export default VisitorViewPage;
