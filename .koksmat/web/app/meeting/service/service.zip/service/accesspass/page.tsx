'use client';

import AccesspassServiceList from '@/components/AccesspassServiceList';

const AccesspassPage = () => {
  return <AccesspassServiceList />;
};

export default AccesspassPage;
