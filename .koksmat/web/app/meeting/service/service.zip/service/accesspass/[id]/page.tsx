"use client";

import AccesspassServiceView from "@/components/AccesspassServiceView";

interface AccesspassProps {
  params: {
    id: string;
  };
}

const AccesspassViewPage = (props: AccesspassProps) => {
  const { id } = props.params;

  return <AccesspassServiceView id={id} />;
};

export default AccesspassViewPage;
