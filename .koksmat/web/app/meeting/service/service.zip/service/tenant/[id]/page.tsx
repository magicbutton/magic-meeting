"use client";

import TenantServiceView from "@/components/TenantServiceView";

interface TenantProps {
  params: {
    id: string;
  };
}

const TenantViewPage = (props: TenantProps) => {
  const { id } = props.params;

  return <TenantServiceView id={id} />;
};

export default TenantViewPage;
