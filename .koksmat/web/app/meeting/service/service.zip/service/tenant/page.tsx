'use client';

import TenantServiceList from '@/components/TenantServiceList';

const TenantPage = () => {
  return <TenantServiceList />;
};

export default TenantPage;
