"use client";

import AuditlogServiceView from "@/components/AuditlogServiceView";

interface AuditlogProps {
  params: {
    id: string;
  };
}

const AuditlogViewPage = (props: AuditlogProps) => {
  const { id } = props.params;

  return <AuditlogServiceView id={id} />;
};

export default AuditlogViewPage;
