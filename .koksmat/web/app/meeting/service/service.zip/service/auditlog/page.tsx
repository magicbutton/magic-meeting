'use client';

import AuditlogServiceList from '@/components/AuditlogServiceList';

const AuditlogPage = () => {
  return <AuditlogServiceList />;
};

export default AuditlogPage;
