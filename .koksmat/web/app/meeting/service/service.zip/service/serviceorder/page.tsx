'use client';

import ServiceorderServiceList from '@/components/ServiceorderServiceList';

const ServiceorderPage = () => {
  return <ServiceorderServiceList />;
};

export default ServiceorderPage;
