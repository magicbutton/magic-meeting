"use client";

import ServiceorderServiceView from "@/components/ServiceorderServiceView";

interface ServiceorderProps {
  params: {
    id: string;
  };
}

const ServiceorderViewPage = (props: ServiceorderProps) => {
  const { id } = props.params;

  return <ServiceorderServiceView id={id} />;
};

export default ServiceorderViewPage;
