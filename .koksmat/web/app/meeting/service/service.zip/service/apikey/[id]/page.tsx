"use client";

import ApikeyServiceView from "@/components/ApikeyServiceView";

interface ApikeyProps {
  params: {
    id: string;
  };
}

const ApikeyViewPage = (props: ApikeyProps) => {
  const { id } = props.params;

  return <ApikeyServiceView id={id} />;
};

export default ApikeyViewPage;
