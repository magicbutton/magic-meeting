'use client';

import ApikeyServiceList from '@/components/ApikeyServiceList';

const ApikeyPage = () => {
  return <ApikeyServiceList />;
};

export default ApikeyPage;
