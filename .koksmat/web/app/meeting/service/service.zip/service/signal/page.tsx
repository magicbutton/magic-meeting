'use client';

import SignalServiceList from '@/components/SignalServiceList';

const SignalPage = () => {
  return <SignalServiceList />;
};

export default SignalPage;
