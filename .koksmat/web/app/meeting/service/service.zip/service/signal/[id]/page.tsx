"use client";

import SignalServiceView from "@/components/SignalServiceView";

interface SignalProps {
  params: {
    id: string;
  };
}

const SignalViewPage = (props: SignalProps) => {
  const { id } = props.params;

  return <SignalServiceView id={id} />;
};

export default SignalViewPage;
