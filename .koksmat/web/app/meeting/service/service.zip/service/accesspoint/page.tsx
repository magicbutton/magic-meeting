'use client';

import AccesspointServiceList from '@/components/AccesspointServiceList';

const AccesspointPage = () => {
  return <AccesspointServiceList />;
};

export default AccesspointPage;
