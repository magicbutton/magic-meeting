"use client";

import AccesspointServiceView from "@/components/AccesspointServiceView";

interface AccesspointProps {
  params: {
    id: string;
  };
}

const AccesspointViewPage = (props: AccesspointProps) => {
  const { id } = props.params;

  return <AccesspointServiceView id={id} />;
};

export default AccesspointViewPage;
