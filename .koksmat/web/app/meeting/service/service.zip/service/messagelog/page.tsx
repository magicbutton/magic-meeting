'use client';

import MessagelogServiceList from '@/components/MessagelogServiceList';

const MessagelogPage = () => {
  return <MessagelogServiceList />;
};

export default MessagelogPage;
