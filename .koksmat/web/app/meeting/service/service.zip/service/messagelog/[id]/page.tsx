"use client";

import MessagelogServiceView from "@/components/MessagelogServiceView";

interface MessagelogProps {
  params: {
    id: string;
  };
}

const MessagelogViewPage = (props: MessagelogProps) => {
  const { id } = props.params;

  return <MessagelogServiceView id={id} />;
};

export default MessagelogViewPage;
