"use client";

import CommunicationchannelServiceView from "@/components/CommunicationchannelServiceView";

interface CommunicationchannelProps {
  params: {
    id: string;
  };
}

const CommunicationchannelViewPage = (props: CommunicationchannelProps) => {
  const { id } = props.params;

  return <CommunicationchannelServiceView id={id} />;
};

export default CommunicationchannelViewPage;
