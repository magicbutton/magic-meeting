'use client';

import CommunicationchannelServiceList from '@/components/CommunicationchannelServiceList';

const CommunicationchannelPage = () => {
  return <CommunicationchannelServiceList />;
};

export default CommunicationchannelPage;
