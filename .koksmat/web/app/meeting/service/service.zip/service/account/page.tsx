'use client';

import AccountServiceList from '@/components/AccountServiceList';

const AccountPage = () => {
  return <AccountServiceList />;
};

export default AccountPage;
