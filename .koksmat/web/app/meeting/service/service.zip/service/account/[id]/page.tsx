"use client";

import AccountServiceView from "@/components/AccountServiceView";

interface AccountProps {
  params: {
    id: string;
  };
}

const AccountViewPage = (props: AccountProps) => {
  const { id } = props.params;

  return <AccountServiceView id={id} />;
};

export default AccountViewPage;
