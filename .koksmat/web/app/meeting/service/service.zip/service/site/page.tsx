'use client';

import SiteServiceList from '@/components/SiteServiceList';

const SitePage = () => {
  return <SiteServiceList />;
};

export default SitePage;
