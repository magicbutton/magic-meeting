"use client";

import SiteServiceView from "@/components/SiteServiceView";

interface SiteProps {
  params: {
    id: string;
  };
}

const SiteViewPage = (props: SiteProps) => {
  const { id } = props.params;

  return <SiteServiceView id={id} />;
};

export default SiteViewPage;
