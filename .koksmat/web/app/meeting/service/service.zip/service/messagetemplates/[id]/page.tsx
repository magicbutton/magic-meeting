"use client";

import MessagetemplatesServiceView from "@/components/MessagetemplatesServiceView";

interface MessagetemplatesProps {
  params: {
    id: string;
  };
}

const MessagetemplatesViewPage = (props: MessagetemplatesProps) => {
  const { id } = props.params;

  return <MessagetemplatesServiceView id={id} />;
};

export default MessagetemplatesViewPage;
