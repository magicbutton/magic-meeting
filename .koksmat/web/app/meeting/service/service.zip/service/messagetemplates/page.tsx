'use client';

import MessagetemplatesServiceList from '@/components/MessagetemplatesServiceList';

const MessagetemplatesPage = () => {
  return <MessagetemplatesServiceList />;
};

export default MessagetemplatesPage;
