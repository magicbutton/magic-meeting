"use client";

import ServicecatalogueServiceView from "@/components/ServicecatalogueServiceView";

interface ServicecatalogueProps {
  params: {
    id: string;
  };
}

const ServicecatalogueViewPage = (props: ServicecatalogueProps) => {
  const { id } = props.params;

  return <ServicecatalogueServiceView id={id} />;
};

export default ServicecatalogueViewPage;
