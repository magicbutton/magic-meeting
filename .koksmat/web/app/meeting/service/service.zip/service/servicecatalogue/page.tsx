'use client';

import ServicecatalogueServiceList from '@/components/ServicecatalogueServiceList';

const ServicecataloguePage = () => {
  return <ServicecatalogueServiceList />;
};

export default ServicecataloguePage;
