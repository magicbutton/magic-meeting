'use client';

import MeetingroleServiceList from '@/components/MeetingroleServiceList';

const MeetingrolePage = () => {
  return <MeetingroleServiceList />;
};

export default MeetingrolePage;
