"use client";

import MeetingroleServiceView from "@/components/MeetingroleServiceView";

interface MeetingroleProps {
  params: {
    id: string;
  };
}

const MeetingroleViewPage = (props: MeetingroleProps) => {
  const { id } = props.params;

  return <MeetingroleServiceView id={id} />;
};

export default MeetingroleViewPage;
