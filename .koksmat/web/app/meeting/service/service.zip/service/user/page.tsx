'use client';

import UserServiceList from '@/components/UserServiceList';

const UserPage = () => {
  return <UserServiceList />;
};

export default UserPage;
