"use client";

import UserServiceView from "@/components/UserServiceView";

interface UserProps {
  params: {
    id: string;
  };
}

const UserViewPage = (props: UserProps) => {
  const { id } = props.params;

  return <UserServiceView id={id} />;
};

export default UserViewPage;
