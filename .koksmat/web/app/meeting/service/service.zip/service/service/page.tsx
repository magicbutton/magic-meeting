'use client';

import ServiceServiceList from '@/components/ServiceServiceList';

const ServicePage = () => {
  return <ServiceServiceList />;
};

export default ServicePage;
