"use client";

import ServiceServiceView from "@/components/ServiceServiceView";

interface ServiceProps {
  params: {
    id: string;
  };
}

const ServiceViewPage = (props: ServiceProps) => {
  const { id } = props.params;

  return <ServiceServiceView id={id} />;
};

export default ServiceViewPage;
