'use client';

import MeetingroomServiceList from '@/components/MeetingroomServiceList';

const MeetingroomPage = () => {
  return <MeetingroomServiceList />;
};

export default MeetingroomPage;
