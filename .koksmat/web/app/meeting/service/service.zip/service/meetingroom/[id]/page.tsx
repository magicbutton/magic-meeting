"use client";

import MeetingroomServiceView from "@/components/MeetingroomServiceView";

interface MeetingroomProps {
  params: {
    id: string;
  };
}

const MeetingroomViewPage = (props: MeetingroomProps) => {
  const { id } = props.params;

  return <MeetingroomServiceView id={id} />;
};

export default MeetingroomViewPage;
