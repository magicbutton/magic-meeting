'use client';

import ProductionorderServiceList from '@/components/ProductionorderServiceList';

const ProductionorderPage = () => {
  return <ProductionorderServiceList />;
};

export default ProductionorderPage;
