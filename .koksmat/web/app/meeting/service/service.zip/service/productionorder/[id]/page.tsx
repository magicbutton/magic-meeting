"use client";

import ProductionorderServiceView from "@/components/ProductionorderServiceView";

interface ProductionorderProps {
  params: {
    id: string;
  };
}

const ProductionorderViewPage = (props: ProductionorderProps) => {
  const { id } = props.params;

  return <ProductionorderServiceView id={id} />;
};

export default ProductionorderViewPage;
