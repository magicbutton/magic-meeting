'use client';

import TaskServiceList from '@/components/TaskServiceList';

const TaskPage = () => {
  return <TaskServiceList />;
};

export default TaskPage;
