"use client";

import TaskServiceView from "@/components/TaskServiceView";

interface TaskProps {
  params: {
    id: string;
  };
}

const TaskViewPage = (props: TaskProps) => {
  const { id } = props.params;

  return <TaskServiceView id={id} />;
};

export default TaskViewPage;
