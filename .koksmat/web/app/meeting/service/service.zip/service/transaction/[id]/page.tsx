"use client";

import TransactionServiceView from "@/components/TransactionServiceView";

interface TransactionProps {
  params: {
    id: string;
  };
}

const TransactionViewPage = (props: TransactionProps) => {
  const { id } = props.params;

  return <TransactionServiceView id={id} />;
};

export default TransactionViewPage;
