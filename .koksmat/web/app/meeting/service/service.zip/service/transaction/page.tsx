'use client';

import TransactionServiceList from '@/components/TransactionServiceList';

const TransactionPage = () => {
  return <TransactionServiceList />;
};

export default TransactionPage;
