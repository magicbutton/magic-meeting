'use client';

import MeetingServiceList from '@/components/MeetingServiceList';

const MeetingPage = () => {
  return <MeetingServiceList />;
};

export default MeetingPage;
