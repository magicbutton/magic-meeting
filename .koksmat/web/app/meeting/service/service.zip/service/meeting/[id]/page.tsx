"use client";

import MeetingServiceView from "@/components/MeetingServiceView";

interface MeetingProps {
  params: {
    id: string;
  };
}

const MeetingViewPage = (props: MeetingProps) => {
  const { id } = props.params;

  return <MeetingServiceView id={id} />;
};

export default MeetingViewPage;
