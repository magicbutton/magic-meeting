'use client';

import CountryServiceList from '@/components/CountryServiceList';

const CountryPage = () => {
  return <CountryServiceList />;
};

export default CountryPage;
