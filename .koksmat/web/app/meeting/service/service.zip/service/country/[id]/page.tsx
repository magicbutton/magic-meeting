"use client";

import CountryServiceView from "@/components/CountryServiceView";

interface CountryProps {
  params: {
    id: string;
  };
}

const CountryViewPage = (props: CountryProps) => {
  const { id } = props.params;

  return <CountryServiceView id={id} />;
};

export default CountryViewPage;
