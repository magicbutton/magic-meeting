'use client';

import FloorServiceList from '@/components/FloorServiceList';

const FloorPage = () => {
  return <FloorServiceList />;
};

export default FloorPage;
