"use client";

import FloorServiceView from "@/components/FloorServiceView";

interface FloorProps {
  params: {
    id: string;
  };
}

const FloorViewPage = (props: FloorProps) => {
  const { id } = props.params;

  return <FloorServiceView id={id} />;
};

export default FloorViewPage;
