'use client';

import ServicecategoryServiceList from '@/components/ServicecategoryServiceList';

const ServicecategoryPage = () => {
  return <ServicecategoryServiceList />;
};

export default ServicecategoryPage;
