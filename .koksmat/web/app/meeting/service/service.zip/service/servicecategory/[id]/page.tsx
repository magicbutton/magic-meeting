"use client";

import ServicecategoryServiceView from "@/components/ServicecategoryServiceView";

interface ServicecategoryProps {
  params: {
    id: string;
  };
}

const ServicecategoryViewPage = (props: ServicecategoryProps) => {
  const { id } = props.params;

  return <ServicecategoryServiceView id={id} />;
};

export default ServicecategoryViewPage;
