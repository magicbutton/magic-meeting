"use client";

import BuildingServiceView from "@/components/BuildingServiceView";

interface BuildingProps {
  params: {
    id: string;
  };
}

const BuildingViewPage = (props: BuildingProps) => {
  const { id } = props.params;

  return <BuildingServiceView id={id} />;
};

export default BuildingViewPage;
