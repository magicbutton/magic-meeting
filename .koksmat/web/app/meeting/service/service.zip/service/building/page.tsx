'use client';

import BuildingServiceList from '@/components/BuildingServiceList';

const BuildingPage = () => {
  return <BuildingServiceList />;
};

export default BuildingPage;
